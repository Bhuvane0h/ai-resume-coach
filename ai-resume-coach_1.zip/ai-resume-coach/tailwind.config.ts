import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        ink: "#1A2436",
        paper: "#FBF9F4",
        gold: "#B98A2E",
        sage: "#3F6B4C",
        coral: "#B85440"
      }
    }
  },
  plugins: []
};
export default config;
