# AI Resume Coach

Next.js 14 + TypeScript + Tailwind + Prisma/PostgreSQL + NextAuth + Anthropic (Claude) API.

## Structure

```
src/app/
  (auth)/login, (auth)/register     Phase 1 — auth pages
  (app)/                            route group sharing the sidebar layout:
    dashboard/                        Phase 1 — dashboard shell
    resume-builder/                   Phase 1 — resume builder
    ai/analyzer, ai/ats-scorer,       Phase 2 — AI features
    ai/improver, ai/cover-letter,
    ai/coach-chat/
    jobs/                              Phase 3 — search, matching, saved, digest
    learning/                          Phase 4 — roadmap, resources, progress
    interview/                         Phase 5 — mock interviews (technical/HR/aptitude)
  admin/                             Phase 6 — dashboard, users, jobs, analytics (admin-only)
  api/                               route handlers for all of the above

prisma/schema.prisma                data models for all 7 phases
docker/, docker-compose.yml,        Phase 7 — deployment
.github/workflows/ci.yml
```

## Setup

1. Install dependencies
   ```
   npm install
   ```
2. Copy `.env.example` to `.env` and fill in:
   - `DATABASE_URL` — a Postgres connection string (or run `docker compose up db`)
   - `NEXTAUTH_SECRET` — generate with `openssl rand -base64 32`
   - `ANTHROPIC_API_KEY` — from https://console.anthropic.com
3. Push the schema to your database
   ```
   npm run db:push
   ```
4. Run the dev server
   ```
   npm run dev
   ```
   Visit http://localhost:3000

## What's built

- **Phase 1 — Foundation**: registration/login (NextAuth credentials + bcrypt), dashboard shell
  with sidebar, resume builder (summary + skills, saves to Postgres via Prisma).
- **Phase 2 — AI**: all five features call Claude via `src/lib/anthropic.ts`:
  - Resume Analyzer — strengths/weaknesses/suggestions
  - ATS Scorer — score + matched/missing keywords against a job description
  - Resume Improver — rewrites bullet points
  - Cover Letter Generator — tailored letter from resume + job
  - Career Coach Chat — persisted conversation history per user
- **Phase 3 — Jobs**: search/filter listings, AI match scoring against your resume, save/unsave
  jobs, on-demand weekly digest (AI summary of the last 7 days of postings).
- **Phase 4 — Learning**: generates a skill roadmap for a target role, tracks each skill's status
  (not started / in progress / done) with one click, suggests learning resources per skill.
- **Phase 5 — Interview**: generates technical, HR, or aptitude questions for a role, collects your
  answers, and returns AI feedback per session (`MockInterview.feedback`).
- **Phase 6 — Admin**: dashboard with top-line counts, user management (promote/demote/delete),
  job management (add/remove listings — this is how you seed jobs for Phase 3), analytics page.
  Gated by `role === "ADMIN"` on `User` — promote your own account via Prisma Studio
  (`npm run db:studio`) to access it the first time.
- **Phase 7 — Deployment**: multi-stage `Dockerfile`, `docker-compose.yml` (app + Postgres), and a
  GitHub Actions CI workflow (lint, build, prisma push against a service container).

## Suggested next steps

1. `npm install && npm run dev`.
2. `npm run db:studio` → set your user's `role` to `ADMIN` → visit `/admin` → add a few job
   listings so `/jobs` has something to search.
3. Expand `resume-builder` to cover experience/education entries (the data model already
   supports it — `ResumeContent.experience[]` / `.education[]`).
4. Real job data: swap the manual Admin → Job management form for a scheduled fetch from a job
   board API, writing into the same `Job` table.
5. Weekly digest is generated on demand from `/api/jobs/digest` — wire it to a cron job (e.g.
   Vercel Cron or a GitHub Actions schedule) and an email provider to actually send it weekly.
