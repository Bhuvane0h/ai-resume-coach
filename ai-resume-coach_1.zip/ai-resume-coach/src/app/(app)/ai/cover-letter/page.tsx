"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";

export default function CoverLetterPage() {
  const [resumeText, setResumeText] = useState("");
  const [jobTitle, setJobTitle] = useState("");
  const [company, setCompany] = useState("");
  const [jobDescription, setJobDescription] = useState("");
  const [letter, setLetter] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleGenerate() {
    setLoading(true);
    const res = await fetch("/api/ai/cover-letter", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ resumeText, jobTitle, company, jobDescription })
    });
    const data = await res.json();
    setLetter(data.content || data.error);
    setLoading(false);
  }

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-semibold mb-1">Cover letter generator</h1>
      <p className="text-ink/60 mb-6">Generate a tailored cover letter from your resume and the job details.</p>

      <div className="grid grid-cols-2 gap-3 mb-3">
        <Input placeholder="Job title" value={jobTitle} onChange={(e) => setJobTitle(e.target.value)} />
        <Input placeholder="Company" value={company} onChange={(e) => setCompany(e.target.value)} />
      </div>
      <Textarea
        rows={6}
        className="mb-3"
        placeholder="Paste resume text here..."
        value={resumeText}
        onChange={(e) => setResumeText(e.target.value)}
      />
      <Textarea
        rows={6}
        placeholder="Paste job description here (optional)..."
        value={jobDescription}
        onChange={(e) => setJobDescription(e.target.value)}
      />
      <Button
        className="mt-3"
        onClick={handleGenerate}
        disabled={loading || !resumeText || !jobTitle || !company}
      >
        {loading ? "Generating..." : "Generate cover letter"}
      </Button>

      {letter && (
        <Card className="mt-6">
          <p className="text-sm whitespace-pre-wrap">{letter}</p>
        </Card>
      )}
    </div>
  );
}
