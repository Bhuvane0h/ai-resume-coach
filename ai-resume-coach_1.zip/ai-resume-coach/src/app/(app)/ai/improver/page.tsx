"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";

export default function ImproverPage() {
  const [text, setText] = useState("");
  const [jobTitle, setJobTitle] = useState("");
  const [improved, setImproved] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleImprove() {
    setLoading(true);
    const res = await fetch("/api/ai/improve", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, jobTitle })
    });
    const data = await res.json();
    setImproved(data.improved || data.error);
    setLoading(false);
  }

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-semibold mb-1">Resume improver</h1>
      <p className="text-ink/60 mb-6">Paste a bullet point or section and get a stronger rewrite.</p>

      <Input
        className="mb-3"
        placeholder="Target job title (optional)"
        value={jobTitle}
        onChange={(e) => setJobTitle(e.target.value)}
      />
      <Textarea
        rows={6}
        placeholder="e.g. Responsible for managing a team and handling projects"
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <Button className="mt-3" onClick={handleImprove} disabled={loading || !text}>
        {loading ? "Improving..." : "Improve text"}
      </Button>

      {improved && (
        <Card className="mt-6">
          <p className="font-medium mb-2">Rewritten</p>
          <p className="text-sm whitespace-pre-wrap">{improved}</p>
        </Card>
      )}
    </div>
  );
}
