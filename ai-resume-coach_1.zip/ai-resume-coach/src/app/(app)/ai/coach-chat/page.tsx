"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type Message = { role: "user" | "assistant"; content: string };

export default function CoachChatPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSend() {
    if (!input.trim()) return;
    const userMessage: Message = { role: "user", content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    const res = await fetch("/api/ai/coach-chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: userMessage.content })
    });
    const data = await res.json();
    setMessages((prev) => [...prev, { role: "assistant", content: data.reply || data.error }]);
    setLoading(false);
  }

  return (
    <div className="max-w-2xl flex flex-col h-[calc(100vh-4rem)]">
      <h1 className="text-2xl font-semibold mb-1">Career coach chat</h1>
      <p className="text-ink/60 mb-6">Ask about your resume, job search strategy, or interview prep.</p>

      <div className="flex-1 overflow-y-auto flex flex-col gap-3 mb-4">
        {messages.map((m, i) => (
          <div
            key={i}
            className={
              m.role === "user"
                ? "self-end bg-ink text-white rounded-lg px-4 py-2 max-w-[80%] text-sm"
                : "self-start bg-white border border-ink/10 rounded-lg px-4 py-2 max-w-[80%] text-sm"
            }
          >
            {m.content}
          </div>
        ))}
        {loading && <p className="text-sm text-ink/40">Thinking...</p>}
      </div>

      <div className="flex gap-2">
        <Input
          placeholder="Ask your career coach..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
        />
        <Button onClick={handleSend} disabled={loading || !input.trim()}>
          Send
        </Button>
      </div>
    </div>
  );
}
