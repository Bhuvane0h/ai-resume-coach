"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";

export default function AtsScorerPage() {
  const [resumeText, setResumeText] = useState("");
  const [jobDescription, setJobDescription] = useState("");
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  async function handleScore() {
    setLoading(true);
    const res = await fetch("/api/ai/ats-score", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ resumeText, jobDescription })
    });
    setResult(await res.json());
    setLoading(false);
  }

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-semibold mb-1">ATS scorer</h1>
      <p className="text-ink/60 mb-6">
        Compare your resume against a job description to see how it'd score in an ATS scan.
      </p>

      <Textarea
        rows={8}
        className="mb-3"
        placeholder="Paste resume text here..."
        value={resumeText}
        onChange={(e) => setResumeText(e.target.value)}
      />
      <Textarea
        rows={8}
        placeholder="Paste job description here..."
        value={jobDescription}
        onChange={(e) => setJobDescription(e.target.value)}
      />
      <Button className="mt-3" onClick={handleScore} disabled={loading || !resumeText || !jobDescription}>
        {loading ? "Scoring..." : "Score resume"}
      </Button>

      {result && !result.error && (
        <div className="mt-6 grid gap-3">
          <Card>
            <p className="text-sm text-ink/60 mb-1">ATS score</p>
            <p className="text-3xl font-semibold">{result.atsScore}/100</p>
          </Card>
          <Card>
            <p className="font-medium mb-2 text-sage">Matched keywords</p>
            <p className="text-sm">{(result.matchedKeywords || []).join(", ") || "—"}</p>
          </Card>
          <Card>
            <p className="font-medium mb-2 text-coral">Missing keywords</p>
            <p className="text-sm">{(result.missingKeywords || []).join(", ") || "—"}</p>
          </Card>
          <Card>
            <p className="font-medium mb-2 text-gold">Suggestions</p>
            <ul className="list-disc pl-5 text-sm space-y-1">
              {(result.suggestions as string[])?.map((s, i) => <li key={i}>{s}</li>)}
            </ul>
          </Card>
        </div>
      )}
      {result?.error && <p className="mt-4 text-sm text-red-600">{result.error}</p>}
    </div>
  );
}
