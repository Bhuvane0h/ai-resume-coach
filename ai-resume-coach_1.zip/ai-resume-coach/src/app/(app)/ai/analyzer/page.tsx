"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";

export default function AnalyzerPage() {
  const [resumeText, setResumeText] = useState("");
  const [jobTitle, setJobTitle] = useState("");
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  async function handleAnalyze() {
    setLoading(true);
    const res = await fetch("/api/ai/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ resumeText, jobTitle })
    });
    setResult(await res.json());
    setLoading(false);
  }

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-semibold mb-1">Resume analyzer</h1>
      <p className="text-ink/60 mb-6">Paste your resume text and get strengths, weaknesses, and suggestions.</p>

      <Input
        className="mb-3"
        placeholder="Target job title (optional)"
        value={jobTitle}
        onChange={(e) => setJobTitle(e.target.value)}
      />
      <Textarea
        rows={10}
        placeholder="Paste resume text here..."
        value={resumeText}
        onChange={(e) => setResumeText(e.target.value)}
      />
      <Button className="mt-3" onClick={handleAnalyze} disabled={loading || !resumeText}>
        {loading ? "Analyzing..." : "Analyze resume"}
      </Button>

      {result && !result.error && (
        <div className="mt-6 grid gap-3">
          <Card>
            <p className="font-medium mb-2 text-sage">Strengths</p>
            <ul className="list-disc pl-5 text-sm space-y-1">
              {(result.strengths as string[])?.map((s, i) => <li key={i}>{s}</li>)}
            </ul>
          </Card>
          <Card>
            <p className="font-medium mb-2 text-coral">Weaknesses</p>
            <ul className="list-disc pl-5 text-sm space-y-1">
              {(result.weaknesses as string[])?.map((s, i) => <li key={i}>{s}</li>)}
            </ul>
          </Card>
          <Card>
            <p className="font-medium mb-2 text-gold">Suggestions</p>
            <ul className="list-disc pl-5 text-sm space-y-1">
              {(result.suggestions as string[])?.map((s, i) => <li key={i}>{s}</li>)}
            </ul>
          </Card>
        </div>
      )}
      {result?.error && <p className="mt-4 text-sm text-red-600">{result.error}</p>}
    </div>
  );
}
