"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

type Skill = { id: string; skillName: string; status: string };
type Resource = { name: string; type: string; note: string };

const STATUS_LABEL: Record<string, string> = {
  not_started: "Not started",
  in_progress: "In progress",
  done: "Done"
};
const NEXT_STATUS: Record<string, string> = {
  not_started: "in_progress",
  in_progress: "done",
  done: "not_started"
};

export default function LearningPage() {
  const [targetRole, setTargetRole] = useState("");
  const [skills, setSkills] = useState<Skill[]>([]);
  const [loading, setLoading] = useState(false);
  const [resourceSkill, setResourceSkill] = useState<string | null>(null);
  const [resources, setResources] = useState<Resource[]>([]);

  async function loadSkills() {
    const res = await fetch("/api/learning/skills");
    setSkills(await res.json());
  }

  useEffect(() => {
    loadSkills();
  }, []);

  async function handleGenerateRoadmap() {
    if (!targetRole) return;
    setLoading(true);
    await fetch("/api/learning/roadmap", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ targetRole })
    });
    await loadSkills();
    setLoading(false);
  }

  async function cycleStatus(skill: Skill) {
    const nextStatus = NEXT_STATUS[skill.status];
    await fetch(`/api/learning/skills/${skill.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: nextStatus })
    });
    loadSkills();
  }

  async function showResources(skillName: string) {
    setResourceSkill(skillName);
    setResources([]);
    const res = await fetch(`/api/learning/resources?skill=${encodeURIComponent(skillName)}`);
    const data = await res.json();
    setResources(data.resources || []);
  }

  const doneCount = skills.filter((s) => s.status === "done").length;

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-semibold mb-1">Learning</h1>
      <p className="text-ink/60 mb-6">Get a skill roadmap for your target role and track your progress.</p>

      <Card className="mb-6">
        <p className="text-sm font-medium mb-2">Target role</p>
        <div className="flex gap-2">
          <Input placeholder="e.g. Senior Frontend Engineer" value={targetRole} onChange={(e) => setTargetRole(e.target.value)} />
          <Button onClick={handleGenerateRoadmap} disabled={loading || !targetRole}>
            {loading ? "Generating..." : "Generate roadmap"}
          </Button>
        </div>
      </Card>

      {skills.length > 0 && (
        <p className="text-sm text-ink/60 mb-3">{doneCount} of {skills.length} skills done</p>
      )}

      <div className="flex flex-col gap-2">
        {skills.map((skill) => (
          <Card key={skill.id} className="flex items-center justify-between">
            <div>
              <p className="font-medium text-sm">{skill.skillName}</p>
              <button onClick={() => showResources(skill.skillName)} className="text-xs text-ink/50 underline">
                See resources
              </button>
            </div>
            <button
              onClick={() => cycleStatus(skill)}
              className={cn(
                "text-xs px-3 py-1.5 rounded-full border",
                skill.status === "done" && "bg-sage/10 border-sage text-sage",
                skill.status === "in_progress" && "bg-gold/10 border-gold text-gold",
                skill.status === "not_started" && "border-ink/20 text-ink/60"
              )}
            >
              {STATUS_LABEL[skill.status]}
            </button>
          </Card>
        ))}
        {skills.length === 0 && (
          <p className="text-sm text-ink/40">No roadmap yet — enter a target role above to generate one.</p>
        )}
      </div>

      {resourceSkill && (
        <Card className="mt-6">
          <p className="font-medium mb-2">Resources for {resourceSkill}</p>
          {resources.length === 0 && <p className="text-sm text-ink/40">Loading...</p>}
          <ul className="text-sm space-y-2">
            {resources.map((r, i) => (
              <li key={i}>
                <span className="font-medium">{r.name}</span>{" "}
                <span className="text-ink/50">({r.type})</span>
                <p className="text-ink/60">{r.note}</p>
              </li>
            ))}
          </ul>
        </Card>
      )}
    </div>
  );
}
