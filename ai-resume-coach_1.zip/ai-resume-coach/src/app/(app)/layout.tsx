import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { Sidebar } from "@/components/dashboard/sidebar";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  const isAdmin = (session?.user as any)?.role === "ADMIN";

  return (
    <div className="flex">
      <Sidebar isAdmin={isAdmin} />
      <div className="flex-1 px-8 py-8">{children}</div>
    </div>
  );
}
