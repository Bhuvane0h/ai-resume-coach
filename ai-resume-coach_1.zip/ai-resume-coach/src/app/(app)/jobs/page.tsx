"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";

type Job = { id: string; title: string; company: string; location: string | null; description: string };

export default function JobsPage() {
  const [query, setQuery] = useState("");
  const [location, setLocation] = useState("");
  const [jobs, setJobs] = useState<Job[]>([]);
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [resumeText, setResumeText] = useState("");
  const [matchScores, setMatchScores] = useState<Record<string, { score: number; reason: string }>>({});
  const [digest, setDigest] = useState("");
  const [loading, setLoading] = useState(false);

  async function loadSaved() {
    const res = await fetch("/api/jobs/save");
    const data = await res.json();
    setSavedIds(new Set((data || []).map((s: any) => s.jobId)));
  }

  useEffect(() => {
    loadSaved();
  }, []);

  async function handleSearch() {
    setLoading(true);
    const params = new URLSearchParams({ query, location });
    const res = await fetch(`/api/jobs?${params}`);
    setJobs(await res.json());
    setLoading(false);
  }

  async function handleMatch(jobId: string) {
    if (!resumeText) return;
    const res = await fetch("/api/jobs/match", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jobId, resumeText })
    });
    const data = await res.json();
    setMatchScores((prev) => ({ ...prev, [jobId]: { score: data.matchScore, reason: data.reason } }));
  }

  async function toggleSave(jobId: string) {
    if (savedIds.has(jobId)) {
      await fetch("/api/jobs/save", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jobId })
      });
    } else {
      await fetch("/api/jobs/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jobId, matchScore: matchScores[jobId]?.score })
      });
    }
    loadSaved();
  }

  async function handleDigest() {
    const res = await fetch("/api/jobs/digest");
    const data = await res.json();
    setDigest(data.digest);
  }

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-semibold mb-1">Jobs</h1>
      <p className="text-ink/60 mb-6">Search jobs, check your match, and save the ones worth applying to.</p>

      <Card className="mb-4">
        <p className="text-sm font-medium mb-2">Your resume text (used for match scoring)</p>
        <Textarea
          rows={4}
          placeholder="Paste resume text here to enable match scoring..."
          value={resumeText}
          onChange={(e) => setResumeText(e.target.value)}
        />
      </Card>

      <div className="flex gap-2 mb-4">
        <Input placeholder="Search title, company, keywords" value={query} onChange={(e) => setQuery(e.target.value)} />
        <Input placeholder="Location" value={location} onChange={(e) => setLocation(e.target.value)} className="max-w-[160px]" />
        <Button onClick={handleSearch} disabled={loading}>{loading ? "Searching..." : "Search"}</Button>
      </div>

      <Button variant="secondary" onClick={handleDigest} className="mb-4">
        Generate weekly digest
      </Button>
      {digest && (
        <Card className="mb-4">
          <p className="text-sm font-medium mb-2">Weekly digest</p>
          <p className="text-sm whitespace-pre-wrap">{digest}</p>
        </Card>
      )}

      <div className="flex flex-col gap-3">
        {jobs.map((job) => (
          <Card key={job.id}>
            <div className="flex justify-between items-start">
              <div>
                <p className="font-medium">{job.title}</p>
                <p className="text-sm text-ink/60">{job.company} · {job.location || "Unspecified"}</p>
              </div>
              <Button variant="secondary" onClick={() => toggleSave(job.id)}>
                {savedIds.has(job.id) ? "Saved" : "Save"}
              </Button>
            </div>
            <p className="text-sm mt-2 text-ink/80 line-clamp-3">{job.description}</p>
            <div className="mt-3 flex items-center gap-3">
              <Button variant="secondary" onClick={() => handleMatch(job.id)} disabled={!resumeText}>
                Check match
              </Button>
              {matchScores[job.id] && (
                <span className="text-sm text-ink/70">
                  {matchScores[job.id].score}/100 — {matchScores[job.id].reason}
                </span>
              )}
            </div>
          </Card>
        ))}
        {jobs.length === 0 && !loading && (
          <p className="text-sm text-ink/40">No jobs loaded yet — search above, or seed some from Admin → Job management.</p>
        )}
      </div>
    </div>
  );
}
