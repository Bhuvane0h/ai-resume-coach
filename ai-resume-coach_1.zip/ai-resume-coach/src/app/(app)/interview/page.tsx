"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

type InterviewType = "technical" | "hr" | "aptitude";

const TYPES: { key: InterviewType; label: string }[] = [
  { key: "technical", label: "Technical questions" },
  { key: "hr", label: "HR questions" },
  { key: "aptitude", label: "Aptitude test" }
];

export default function InterviewPage() {
  const [type, setType] = useState<InterviewType>("technical");
  const [jobTitle, setJobTitle] = useState("");
  const [interviewId, setInterviewId] = useState<string | null>(null);
  const [questions, setQuestions] = useState<string[]>([]);
  const [answers, setAnswers] = useState<string[]>([]);
  const [feedback, setFeedback] = useState("");
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  async function handleStart() {
    setLoading(true);
    setFeedback("");
    const res = await fetch("/api/interview", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type, jobTitle })
    });
    const data = await res.json();
    setInterviewId(data.id);
    setQuestions(data.questions || []);
    setAnswers(new Array((data.questions || []).length).fill(""));
    setLoading(false);
  }

  async function handleSubmit() {
    if (!interviewId) return;
    setSubmitting(true);
    const res = await fetch(`/api/interview/${interviewId}/submit`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ answers })
    });
    const data = await res.json();
    setFeedback(data.feedback || data.error);
    setSubmitting(false);
  }

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-semibold mb-1">Interview prep</h1>
      <p className="text-ink/60 mb-6">Practice mock interviews and get AI feedback on your answers.</p>

      <div className="flex gap-2 mb-3">
        {TYPES.map((t) => (
          <button
            key={t.key}
            onClick={() => setType(t.key)}
            className={cn(
              "text-sm px-3 py-1.5 rounded-full border",
              type === t.key ? "bg-ink text-white border-ink" : "border-ink/20 text-ink/60"
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="flex gap-2 mb-6">
        <Input placeholder="Target role (optional)" value={jobTitle} onChange={(e) => setJobTitle(e.target.value)} />
        <Button onClick={handleStart} disabled={loading}>
          {loading ? "Generating..." : "Generate questions"}
        </Button>
      </div>

      {questions.length > 0 && (
        <div className="flex flex-col gap-4">
          {questions.map((q, i) => (
            <Card key={i}>
              <p className="text-sm font-medium mb-2">{i + 1}. {q}</p>
              <Textarea
                rows={3}
                placeholder="Your answer..."
                value={answers[i] || ""}
                onChange={(e) => {
                  const next = [...answers];
                  next[i] = e.target.value;
                  setAnswers(next);
                }}
              />
            </Card>
          ))}
          <Button onClick={handleSubmit} disabled={submitting}>
            {submitting ? "Getting feedback..." : "Submit answers for feedback"}
          </Button>
        </div>
      )}

      {feedback && (
        <Card className="mt-6">
          <p className="font-medium mb-2">Feedback</p>
          <p className="text-sm whitespace-pre-wrap">{feedback}</p>
        </Card>
      )}
    </div>
  );
}
