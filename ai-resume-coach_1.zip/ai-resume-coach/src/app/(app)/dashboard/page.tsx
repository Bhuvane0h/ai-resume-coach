import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { Card } from "@/components/ui/card";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-1">
        Welcome{session?.user?.name ? `, ${session.user.name}` : ""}
      </h1>
      <p className="text-ink/60 mb-6">Here's where your resume and job search stand.</p>

      <div className="grid grid-cols-3 gap-4">
        <Card>
          <p className="text-sm text-ink/60">Resumes</p>
          <p className="text-2xl font-semibold">0</p>
        </Card>
        <Card>
          <p className="text-sm text-ink/60">Latest ATS score</p>
          <p className="text-2xl font-semibold">—</p>
        </Card>
        <Card>
          <p className="text-sm text-ink/60">Saved jobs</p>
          <p className="text-2xl font-semibold">0</p>
        </Card>
      </div>
    </div>
  );
}
