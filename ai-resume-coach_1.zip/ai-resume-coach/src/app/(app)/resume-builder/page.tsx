import { ResumeForm } from "@/components/resume/resume-form";

export default function ResumeBuilderPage() {
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-1">Resume builder</h1>
      <p className="text-ink/60 mb-6">Draft your resume, then send it to the AI tools for feedback.</p>
      <ResumeForm />
    </div>
  );
}
