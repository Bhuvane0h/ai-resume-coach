import Link from "next/link";

export default function HomePage() {
  return (
    <main className="max-w-2xl mx-auto px-6 py-24 text-center">
      <h1 className="text-4xl font-semibold mb-4">AI Resume Coach</h1>
      <p className="text-ink/70 mb-8">
        Build a stronger resume, beat the ATS, and land more interviews with an AI coach in your corner.
      </p>
      <div className="flex gap-4 justify-center">
        <Link href="/register" className="px-5 py-2.5 rounded-lg bg-ink text-white">
          Get started
        </Link>
        <Link href="/login" className="px-5 py-2.5 rounded-lg border border-ink/20">
          Log in
        </Link>
      </div>
    </main>
  );
}
