import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { askClaude } from "@/lib/anthropic";

const SYSTEM_PROMPT = `You are an expert resume writer. Rewrite the given resume bullet points or section
to be more impactful: use strong action verbs, quantify results where plausible, and keep each bullet
to one line. Return ONLY the rewritten text, no preamble, no explanation.`;

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { text, jobTitle } = await req.json();
  if (!text) return NextResponse.json({ error: "text is required" }, { status: 400 });

  const userPrompt = jobTitle
    ? `Target role: ${jobTitle}\n\nText to improve:\n${text}`
    : `Text to improve:\n${text}`;

  const improved = await askClaude(SYSTEM_PROMPT, userPrompt);

  return NextResponse.json({ improved });
}
