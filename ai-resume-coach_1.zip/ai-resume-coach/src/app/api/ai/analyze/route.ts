import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { askClaude } from "@/lib/anthropic";

const SYSTEM_PROMPT = `You are a professional resume reviewer. Analyze the resume text you're given and
respond ONLY with valid JSON in this exact shape, no prose, no markdown fences:
{
  "strengths": ["..."],
  "weaknesses": ["..."],
  "suggestions": ["..."]
}
Keep each array to 3-5 concise, specific, actionable items.`;

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { resumeId, resumeText, jobTitle } = await req.json();
  if (!resumeText) return NextResponse.json({ error: "resumeText is required" }, { status: 400 });

  const userPrompt = jobTitle
    ? `Target role: ${jobTitle}\n\nResume:\n${resumeText}`
    : `Resume:\n${resumeText}`;

  const raw = await askClaude(SYSTEM_PROMPT, userPrompt);

  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return NextResponse.json({ error: "Could not parse AI response", raw }, { status: 502 });
  }

  const analysis = await prisma.resumeAnalysis.create({
    data: {
      userId: (session.user as any).id,
      resumeId,
      jobTitle,
      strengths: parsed.strengths,
      weaknesses: parsed.weaknesses,
      suggestions: parsed.suggestions,
      rawResponse: raw
    }
  });

  return NextResponse.json(analysis);
}
