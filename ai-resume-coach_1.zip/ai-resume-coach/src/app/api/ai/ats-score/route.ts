import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { askClaude } from "@/lib/anthropic";

const SYSTEM_PROMPT = `You are an ATS (applicant tracking system) simulator. Given a resume and a job
description, score how well the resume would pass an ATS keyword/relevance scan.
Respond ONLY with valid JSON, no prose, no markdown fences:
{
  "atsScore": 0-100,
  "matchedKeywords": ["..."],
  "missingKeywords": ["..."],
  "suggestions": ["..."]
}`;

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { resumeId, resumeText, jobDescription } = await req.json();
  if (!resumeText || !jobDescription) {
    return NextResponse.json({ error: "resumeText and jobDescription are required" }, { status: 400 });
  }

  const userPrompt = `Resume:\n${resumeText}\n\nJob description:\n${jobDescription}`;
  const raw = await askClaude(SYSTEM_PROMPT, userPrompt);

  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return NextResponse.json({ error: "Could not parse AI response", raw }, { status: 502 });
  }

  const analysis = await prisma.resumeAnalysis.create({
    data: {
      userId: (session.user as any).id,
      resumeId,
      atsScore: parsed.atsScore,
      suggestions: parsed.suggestions,
      rawResponse: raw
    }
  });

  return NextResponse.json({ ...analysis, matchedKeywords: parsed.matchedKeywords, missingKeywords: parsed.missingKeywords });
}
