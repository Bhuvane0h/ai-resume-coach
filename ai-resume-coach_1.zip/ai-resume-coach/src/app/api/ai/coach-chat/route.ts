import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { anthropic, AI_MODEL } from "@/lib/anthropic";

const SYSTEM_PROMPT = `You are a warm, direct career coach helping someone with their job search, resume,
and interview prep. Give concrete, specific advice. Keep responses focused and actionable.`;

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const userId = (session.user as any).id;
  const { message } = await req.json();
  if (!message) return NextResponse.json({ error: "message is required" }, { status: 400 });

  await prisma.coachMessage.create({ data: { userId, role: "user", content: message } });

  const history = await prisma.coachMessage.findMany({
    where: { userId },
    orderBy: { createdAt: "asc" },
    take: 20
  });

  const response = await anthropic.messages.create({
    model: AI_MODEL,
    max_tokens: 1000,
    system: SYSTEM_PROMPT,
    messages: history.map((m) => ({ role: m.role as "user" | "assistant", content: m.content }))
  });

  const textBlock = response.content.find((b) => b.type === "text");
  const reply = textBlock && textBlock.type === "text" ? textBlock.text : "";

  await prisma.coachMessage.create({ data: { userId, role: "assistant", content: reply } });

  return NextResponse.json({ reply });
}
