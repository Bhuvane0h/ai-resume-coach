import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

// Phase 3: Saved Jobs
export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const saved = await prisma.savedJob.findMany({
    where: { userId: (session.user as any).id },
    include: { job: true },
    orderBy: { createdAt: "desc" }
  });

  return NextResponse.json(saved);
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { jobId, matchScore } = await req.json();
  if (!jobId) return NextResponse.json({ error: "jobId is required" }, { status: 400 });

  const saved = await prisma.savedJob.upsert({
    where: { userId_jobId: { userId: (session.user as any).id, jobId } },
    update: { matchScore },
    create: { userId: (session.user as any).id, jobId, matchScore }
  });

  return NextResponse.json(saved, { status: 201 });
}

export async function DELETE(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { jobId } = await req.json();
  if (!jobId) return NextResponse.json({ error: "jobId is required" }, { status: 400 });

  await prisma.savedJob.delete({
    where: { userId_jobId: { userId: (session.user as any).id, jobId } }
  });

  return NextResponse.json({ ok: true });
}
