import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { askClaude } from "@/lib/anthropic";

const PROMPTS: Record<string, string> = {
  technical: `You are a technical interviewer. Generate 5 technical interview questions for the given
role. Mix conceptual and applied questions. Respond ONLY with valid JSON: { "questions": ["..."] }`,
  hr: `You are an HR interviewer. Generate 5 behavioral/HR interview questions for the given role
(e.g. teamwork, conflict, motivation). Respond ONLY with valid JSON: { "questions": ["..."] }`,
  aptitude: `You are an aptitude test writer. Generate 5 short logical/numerical reasoning questions
suitable for a job aptitude test. Respond ONLY with valid JSON: { "questions": ["..."] }`
};

// Phase 5: Mock Interviews, Technical Questions, HR Questions, Aptitude Tests
// — one endpoint, "type" selects the flavor of questions.
export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { type, jobTitle } = await req.json();
  if (!type || !PROMPTS[type]) {
    return NextResponse.json({ error: "type must be one of technical, hr, aptitude" }, { status: 400 });
  }

  const raw = await askClaude(PROMPTS[type], `Role: ${jobTitle || "general"}`);

  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return NextResponse.json({ error: "Could not parse AI response", raw }, { status: 502 });
  }

  const interview = await prisma.mockInterview.create({
    data: {
      userId: (session.user as any).id,
      type,
      questions: parsed.questions
    }
  });

  return NextResponse.json(interview);
}

// List past interviews for the current user.
export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const interviews = await prisma.mockInterview.findMany({
    where: { userId: (session.user as any).id },
    orderBy: { createdAt: "desc" },
    take: 20
  });

  return NextResponse.json(interviews);
}
