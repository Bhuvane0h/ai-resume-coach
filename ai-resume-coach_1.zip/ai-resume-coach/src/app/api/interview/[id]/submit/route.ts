import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { askClaude } from "@/lib/anthropic";

const SYSTEM_PROMPT = `You are an interview coach. Given a list of interview questions and the
candidate's answers, give honest, specific, constructive feedback: what was strong, what was weak,
and how to improve each weak answer. Keep it under 300 words, plain text, no markdown headers.`;

// Phase 5: submit answers to a mock interview and get AI feedback.
export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const interview = await prisma.mockInterview.findUnique({ where: { id: params.id } });
  if (!interview || interview.userId !== (session.user as any).id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const { answers } = await req.json();
  if (!Array.isArray(answers)) {
    return NextResponse.json({ error: "answers must be an array" }, { status: 400 });
  }

  const questions = interview.questions as string[];
  const qa = questions.map((q, i) => `Q: ${q}\nA: ${answers[i] || "(no answer)"}`).join("\n\n");

  const feedback = await askClaude(SYSTEM_PROMPT, qa);

  const updated = await prisma.mockInterview.update({
    where: { id: params.id },
    data: { answers, feedback }
  });

  return NextResponse.json(updated);
}
