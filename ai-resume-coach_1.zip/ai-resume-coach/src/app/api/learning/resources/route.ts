import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { askClaude } from "@/lib/anthropic";

const SYSTEM_PROMPT = `You are a learning advisor. Given a skill name, suggest 3-5 specific, well-known
learning resources (courses, docs, books, or projects) to learn it. Respond ONLY with valid JSON, no
prose, no markdown fences: { "resources": [{ "name": "...", "type": "course|doc|book|project", "note": "..." }] }`;

// Phase 4: Learning Resources — suggests resources for a given skill.
export async function GET(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const skill = searchParams.get("skill");
  if (!skill) return NextResponse.json({ error: "skill query param is required" }, { status: 400 });

  const raw = await askClaude(SYSTEM_PROMPT, `Skill: ${skill}`);

  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return NextResponse.json({ error: "Could not parse AI response", raw }, { status: 502 });
  }

  return NextResponse.json(parsed);
}
