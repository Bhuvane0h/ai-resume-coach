import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

// Phase 4: Progress Tracking — list the current user's tracked skills.
export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const skills = await prisma.skillProgress.findMany({
    where: { userId: (session.user as any).id },
    orderBy: { updatedAt: "desc" }
  });

  return NextResponse.json(skills);
}
