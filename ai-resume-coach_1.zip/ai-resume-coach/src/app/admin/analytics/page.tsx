"use client";

import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";

type Stats = {
  userCount: number;
  resumeCount: number;
  analysisCount: number;
  coverLetterCount: number;
  jobCount: number;
  savedJobCount: number;
  interviewCount: number;
};

export default function AdminAnalyticsPage() {
  const [stats, setStats] = useState<Stats | null>(null);

  useEffect(() => {
    fetch("/api/admin/analytics")
      .then((res) => res.json())
      .then(setStats);
  }, []);

  if (!stats) return <p className="text-sm text-ink/40">Loading...</p>;

  const rows: [string, number][] = [
    ["Users", stats.userCount],
    ["Resumes created", stats.resumeCount],
    ["Resume analyses run", stats.analysisCount],
    ["Cover letters generated", stats.coverLetterCount],
    ["Job listings", stats.jobCount],
    ["Jobs saved by users", stats.savedJobCount],
    ["Mock interviews taken", stats.interviewCount]
  ];

  return (
    <div className="max-w-lg">
      <h1 className="text-2xl font-semibold mb-1">Analytics</h1>
      <p className="text-ink/60 mb-6">Product-wide usage counts.</p>

      <Card>
        <table className="w-full text-sm">
          <tbody>
            {rows.map(([label, value]) => (
              <tr key={label} className="border-b border-ink/5 last:border-0">
                <td className="py-2 text-ink/70">{label}</td>
                <td className="py-2 text-right font-medium">{value}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
