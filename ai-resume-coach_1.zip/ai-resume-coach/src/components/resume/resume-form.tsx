"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { ResumeContent } from "@/types";

const empty: ResumeContent = {
  summary: "",
  experience: [{ title: "", company: "", startDate: "", endDate: "", bullets: [""] }],
  education: [{ school: "", degree: "", year: "" }],
  skills: []
};

export function ResumeForm() {
  const [content, setContent] = useState<ResumeContent>(empty);
  const [title, setTitle] = useState("Untitled resume");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  async function handleSave() {
    setSaving(true);
    setSaved(false);
    await fetch("/api/resume", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, content })
    });
    setSaving(false);
    setSaved(true);
  }

  return (
    <div className="flex flex-col gap-4 max-w-2xl">
      <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Resume title" />

      <Card>
        <label className="text-sm font-medium block mb-2">Summary</label>
        <Textarea
          rows={4}
          value={content.summary}
          onChange={(e) => setContent({ ...content, summary: e.target.value })}
          placeholder="A short professional summary..."
        />
      </Card>

      <Card>
        <label className="text-sm font-medium block mb-2">Skills (comma separated)</label>
        <Input
          value={content.skills.join(", ")}
          onChange={(e) =>
            setContent({ ...content, skills: e.target.value.split(",").map((s) => s.trim()) })
          }
          placeholder="React, TypeScript, Prisma"
        />
      </Card>

      <Button onClick={handleSave} disabled={saving}>
        {saving ? "Saving..." : "Save resume"}
      </Button>
      {saved && <p className="text-sm text-sage">Saved.</p>}
    </div>
  );
}
