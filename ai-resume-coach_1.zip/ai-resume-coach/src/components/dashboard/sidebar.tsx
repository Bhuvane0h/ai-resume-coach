import Link from "next/link";

const links = [
  { href: "/dashboard", label: "Overview" },
  { href: "/resume-builder", label: "Resume builder" },
  { href: "/ai/analyzer", label: "Resume analyzer" },
  { href: "/ai/ats-scorer", label: "ATS scorer" },
  { href: "/ai/improver", label: "Resume improver" },
  { href: "/ai/cover-letter", label: "Cover letter" },
  { href: "/ai/coach-chat", label: "Career coach chat" },
  { href: "/jobs", label: "Jobs" },
  { href: "/learning", label: "Learning" },
  { href: "/interview", label: "Interview prep" }
];

export function Sidebar({ isAdmin }: { isAdmin?: boolean }) {
  return (
    <aside className="w-56 shrink-0 border-r border-ink/10 min-h-screen py-6 px-3">
      <p className="text-sm font-semibold px-3 mb-4">AI Resume Coach</p>
      <nav className="flex flex-col gap-1">
        {links.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className="text-sm px-3 py-2 rounded-lg hover:bg-ink/5 text-ink/80"
          >
            {link.label}
          </Link>
        ))}
        {isAdmin && (
          <Link
            href="/admin"
            className="text-sm px-3 py-2 rounded-lg hover:bg-ink/5 text-ink/80 mt-2 border-t border-ink/10 pt-3"
          >
            Admin
          </Link>
        )}
      </nav>
    </aside>
  );
}
